<?php
$db_host ="localhost";
$db_user ="usr_estudiante";
$db_pass ="Estudiante@123";
$db_nombre ="db_paginaestudiantes"; 
?>