<?php 
if (!empty($_POST)){
    $txt_id = utf8_decode($_POST["txt_id"]);
    $txt_codigo = utf8_decode($_POST["txt_carne"]);
    $txt_nombres = utf8_decode($_POST["txt_nombres"]);
    $txt_apellidos = utf8_decode($_POST["txt_apellidos"]);
    $txt_direccion = utf8_decode($_POST["txt_direccion"]);
    $txt_telefono = utf8_decode($_POST["txt_telefono"]);
    $txt_correo = utf8_decode($_POST["txt_correo_electronico"]);
    $drop_puesto = utf8_decode($_POST["id_tipos_sangre"]);
    $txt_fn = utf8_decode($_POST["txt_fn"]);

    $sql = "";

    
    if (isset($_POST["btn_agregar"])){
        $sql = "INSERT INTO estudiantes(carne,nombres,apellidos,direccion,telefono,correo_electronico,fecha_nacimiento,id_tipos_sangre)VALUES('".$txt_carne ."','".$txt_nombres ."','".$txt_apellidos ."','".$txt_direccion ."','".$txt_telefono ."','".$correo_electronico ."','".$txt_fn ."',".$id_tipos_sangre .");";
    }
    if (isset($_POST["btn_modificar"])){
        $sql = "update estudiantes set carnet='".$txt_carne ."',nombres='".$txt_nombres ."',apellidos='".$txt_apellidos ."',direccion='".$txt_direccion ."',telefono='".$txt_telefono ."',correo='".$correo_electronico ."','"."',fecha_nacimiento='".$id_tipos_sangre ." where id_estudiantes = ". $txt_id .";";
    }
    if (isset($_POST["btn_eliminar"])){
        $sql = "delete from estudiantes  where id_estudiantes = ". $txt_id .";";
    }
        include("datos_conexion.php");
        $db_conexion = mysqli_connect($db_host,$db_user,$db_pass,$db_nombre);
        
        if ($db_conexion->query($sql)===true){
            $db_conexion ->close();
           
            header("Location: /estudiante_php");
        }else{
            echo"Error" . $sql ."<br>".$db_conexion ->close(); 
        }
    

}
          
        ?> 