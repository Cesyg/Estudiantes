<!doctype html>
<html lang="es">

<head>
  <title>Estudiantes</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
</head>

<body>
  <div class="container">
    <h1>Datos del Estudiante</h1>
    <div class="row">
      <div class="col-12 col-lg-12 col-lm-1 mb-4">
        <header class="p-3 text-bg-dark">
          <div class="container">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
              <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search">
                <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                  <li><a href="#" class="nav-link px-2 text-white">USUARIO</a></li>
                  <li><a href="#" class="nav-link px-2 text-white">Inicio</a></li>
                  <li><a href="#" class="nav-link px-2 text-white">Nosotros</a></li>
                  <li><a href="#" class="nav-link px-2 text-white">Contacto</a></li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Dropdown
                    </a>
                    <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="#">Action</a></li>
                      <li><a class="dropdown-item" href="#">Another action</a></li>
                      <li>
                        <hr class="dropdown-divider">
                      </li>
                      <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                  </li>
                  <li><a href="#" class="nav-link px-2 text-white">Ubicaciones</a></li>
                </ul>
              </form>
              <!-- <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search">
                <input type="search" class="form-control form-control-dark text-bg-dark" placeholder="Search..." aria-label="Search">
              </form> -->
              <div class="col-3 mb-3 mb-lg-0 me-lg-5"> <br /></div>
              <div class="text-end">
                <button type="button" class="btn btn-outline-light me-2">Iniciar</button>
                <button type="button" class="btn btn-outline-light me-2">Cerrar</button>
                <!-- <button type="button" class="btn btn-warning">Cerrar</button> -->
              </div>
            </div>
          </div>
        </header>
      </div>
    </div>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
      Agregar
    </button>
    <div class="table-responsive">
      <table class="table table-striped table-inverse table-responsive">
        <thead class="thead-inverse">
          <tr>
            <th>Carne</th>
            <th>Nombres</th>
            <th>Apellidos</th>
            <th>Direccion</th>
            <th>Telefono</th>
            <th>Correo</th>
            <th>Tipos_sangre</th>
            <th>Fecha_Nacimiento</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Carne 1</td>
            <td>Nombre1 Nombre2</td>
            <td>Apellido1 Apellido2</td>
            <td>Direccion 1</td>
            <td>Telefono 1</td>
            <td>Correo_electronico</td>
            <td>Tipo-Sangre 1</td>
            <td>Nacimiento 1</td>
          </tr>
          <tr>
            <td>Carne 2</td>
            <td>Nombre1 Nombre2</td>
            <td>Apellido1 Apellido2</td>
            <td>Direccion 2</td>
            <td>Telefono 2</td>
            <td>Correo_electronico</td>
            <td>Tipo-Sangre 2</td>
            <td>Nacimiento 2</td>
          </tr>
        </tbody>
        <tfoot>

        </tfoot>
      </table>
    </div>



    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Datos del Estudiante</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form class="d-flex">
              <div class="col-12">
                <div class="mb-3">
                  <label for="lbl_carne" class="form-label"><b>Carnet</b></label>
                  <input type="text" name="txt_carne" id="txt_carne" class="form-control" placeholder="Carne: E001" required>
                </div>
                <div class="mb-3">
                  <label for="lbl_nombres" class="form-label"><b>Nombres</b></label>
                  <input type="text" name="txt_nombres" id="txt_nombres" class="form-control" placeholder="Nombres: Nombre1 Nombre2 " required>
                </div>
                <div class="mb-3">
                  <label for="lbl_apellidos" class="form-label"><b>Apellidos</b></label>
                  <input type="text" name="txt_apellidos" id="txt_apellidos" class="form-control" placeholder="Apellidos: Apellido1" required>
                </div>
                <div class="mb-3">
                  <label for="lbl_direccion" class="form-label"><b>Direccion</b></label>
                  <input type="text" name="txt_direccion" id="txt_direccion" class="form-control" placeholder="Direccion: #casa calle avenida lugar" required>
                </div>
                <div class="mb-3">
                  <label for="lbl_telefono" class="form-label"><b>Telefono</b></label>
                  <input type="number" name="txt_telefono" id="txt_telefono" class="form-control" placeholder="Telefono: 5555" required>
                </div>
                <div class="mb-3">
                  <label for="lbl_correo" class="form-label"><b>Correo</b></label>
                  <input type="text" name="txt_correo" id="txt_correo" class="form-control" placeholder="Correo: a@g.com" required>
                </div>
                <div class="mb-3">
                  <label for="lbl_tipos_sangre" class="form-label"><b>Tipos_sangre</b></label>
                  <select class="form-select" name="o+_tipos_sangre" id="o+_tipos_sangre">
                    <option value="0">--- Tipos_sangre ---</option>
                    <option value="1">--- B+ ---</option>
                    <option value="2">--- O+ ---</option>
                    <option value="3">--- A- ---</option>
                  </select>
                </div>
                <div class="mb-3">
                  <label for="lbl_fn" class="form-label"><b>Fecha Nacimiento</b></label>
                  <input type="date" name="txt_fn" id="txt_fn" class="form-control" placeholder="fn: aaa-mm-dd" required>
                </div>
              </div>
          </div>
          </form>
          <div class="modal-footer">
          <div class="mb-3">
              <input type="submit" name="btn_agregar" id="btn_agregar" class="btn btn-light" value="Agregar">
            </div>
            <div class="mb-3">
              <input type="submit" name="btn_modificar" id="btn_modificar" class="btn btn-light" value="Modificar">
            </div>
            <div class="mb-3">
              <input type="submit" name="btn_eliminar" id="btn_eliminar" class="btn btn-danger" value="Eliminar">
            </div>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            <button type="button" class="btn btn-primary">Aceptar</button>
          </div>
        </div>
      </div>
    </div>
    <!-- <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"> -->
    <!-- <form class="d-flex">
                <div class="col">
                    <div class="mb-3">
                        <label for="lbl_carne" class="form-label"><b>Carne</b></label>
                        <input type="text" name="txt_carne" id="txt_carne" class="form-control" placeholder="Carne: E001" required>                   
                    </div>
                    <div class="mb-3">
                    <label for="lbl_nombres" class="form-label"><b>Nombres</b></label>
                    <input type="text" name="txt_nombres" id="txt_nombres" class="form-control" placeholder="Nombres: Nombre1 Nombre2 " required>    
                    </div>
                    </div>
                    <div class="mb-3">
                    <label for="lbl_apellidos" class="form-label"><b>Apellidos</b></label>
                    <input type="text" name="txt_apellidos" id="txt_apellidos" class="form-control" placeholder="Apellidos: Apellido1" required>                  
                    </div>
                <div class="mb-3">
                <label for="lbl_direccion" class="form-label"><b>Direccion</b></label>
                <input type="text" name="txt_direccion" id="txt_direccion" class="form-control" placeholder="Direccion: #casa calle avenida lugar" required>                  
                </div>
                <div class="mb-3">
                <label for="lbl_telefono" class="form-label"><b>Telefono</b></label>
                <input type="number" name="txt_telefono" id="txt_telefono" class="form-control" placeholder="Telefono: 5555" required>                  
                </div>
                <div class="mb-3">
                <label for="lbl_correo" class="form-label"><b>Correo</b></label>
                <input type="text" name="txt_correo" id="txt_correo" class="form-control" placeholder="Correo: a@g.com" required>                  
                </div>
                <div class="mb-3">
                  <label for="lbl_tipos_sangre" class="form-label"><b>Tipos_sangre</b></label>
                  <select class="form-select" name="o+_tipos_sangre" id="o+_tipos_sangre">
                    <option value="0">--- Tipos_sangre ---</option>
                    <option value="1">--- B+ ---</option>
                    <option value="2">--- O+ ---</option>
                    <option value="3">--- A- ---</option>
                  </select>
                </div>
                <div class="mb-3">
                <label for="lbl_fn" class="form-label"><b>Fecha Nacimiento</b></label>
                <input type="date" name="txt_fn" id="txt_fn" class="form-control" placeholder="fn: aaa-mm-dd" required>                  
                </div>
                <div class="mb-3">
                
                <input type="submit" name="btn_agregar" id="btn_agregar" class="btn btn-primary" value="Agregar">                  
                </div>
                <div class="mb-3">
                <input type="submit" name="btn_modificar" id="btn_modificar" class="btn btn-light" value="Modificar">                  
                </div>
                <div class="mb-3">
                <input type="submit" name="btn_eliminar" id="btn_eliminar" class="btn btn-danger" value="Eliminar">                  
                </div>
    
                </div>
            </form> -->
    <!-- </div> -->
  </div>


  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">

    
  </script>
</body>

</html>